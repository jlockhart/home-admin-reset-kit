# 04 Home And Property

Home, rental, mortgage, rates, repair, renovation, tenancy, and property-related records. Split by property if you manage more than one.
