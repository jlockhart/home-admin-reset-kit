# Home and Property

Use this for documents about the house, rental, property, renovations, major repairs, ownership, leases, rates, and property services.

## What goes here

- Property purchase/sale documents, settlement records, titles, leases, tenancy records, or body-corporate notes.
- Rates notices, valuation notices, renovation records, permits, consent records, and major repair invoices.
- Important contractor paperwork and property-service agreements.

## What not to put here

- Everyday utility bills — use Bills and Receipts / Utilities.
- Insurance policies — use Insurance.
- Product manuals and warranties — use Warranties and Manuals.
- Tax-year evidence if the main retrieval path will be tax time.

## What to do with it

1. Put long-lived property documents in `templates/document-index.csv`.
2. Add rates, lease, service, or warranty renewal dates to `templates/renewal-tracker.csv`.
3. Keep renovation/repair records with enough detail to explain what changed and who did it.
4. Separate active property admin from old archive material.

## Quick rule

If the document would matter when selling, insuring, renting, renovating, or fixing the property, it probably belongs here.
