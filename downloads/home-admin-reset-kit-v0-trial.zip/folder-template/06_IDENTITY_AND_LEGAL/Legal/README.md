# Legal

Wills, enduring powers of attorney, trust/company papers, contracts, and other legal records. This folder is for storage only, not legal advice.
