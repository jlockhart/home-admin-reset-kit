# Identity Documents

Use this for copies or references to important identity documents. Keep this folder especially private and backed up safely.

## What goes here

- Passport, driver licence, birth certificate, citizenship/residency, marriage/name-change, visa, or similar identity records.
- Document numbers and expiry dates only if you are comfortable storing them here.
- Replacement or renewal correspondence.

## What not to put here

- Passwords, 2FA recovery codes, seed phrases, or bank PINs.
- Unencrypted scans in a shared or weakly protected location.
- Legal contracts that belong in the Legal folder.

## What to do with it

1. Add expiry dates to `templates/renewal-tracker.csv`.
2. Add only safe locator notes to `templates/household-admin-map.md`; do not create a single secret treasure map.
3. Keep backups private, encrypted if appropriate, and accessible to the right person in an emergency.
4. Delete duplicate loose copies from Downloads/Inbox after filing.

## Quick rule

This folder is high-value and high-risk. Store less, protect it more, and track expiry dates.
