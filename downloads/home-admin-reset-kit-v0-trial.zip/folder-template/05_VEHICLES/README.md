# Vehicles

Use this for car, bike, trailer, boat, or other vehicle ownership, service, registration, insurance references, and maintenance records.

## What goes here

- Registration, ownership, purchase/sale, finance, WOF/COF, servicing, repair, tyre, battery, and accessory records.
- Vehicle insurance references or claim notes if you prefer to cross-reference them here.
- Licence/registration renewal reminders and roadside-assistance details.

## What not to put here

- Active insurance policy master copies unless you deliberately keep them both here and in Insurance.
- General bank transactions.
- Everyday fuel receipts unless you need them for a clear tax/business reason.

## What to do with it

1. Keep one subfolder or naming prefix per vehicle if you have more than one.
2. Add registration/WOF/insurance/roadside renewal dates to `templates/renewal-tracker.csv`.
3. Keep major service and repair records because they help resale and troubleshooting.
4. Move sold-vehicle records to archive once everything is settled.

## Quick rule

For each vehicle, future-you should be able to find proof of ownership, current obligations, and major service history quickly.
