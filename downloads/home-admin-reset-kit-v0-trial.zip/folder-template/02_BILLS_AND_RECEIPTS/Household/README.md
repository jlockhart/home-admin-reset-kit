# Household Bills and Receipts

Use this for ordinary household bills and receipts that are useful to keep but are not insurance, warranty, vehicle, identity, legal, banking, or tax-first records.

## What goes here

- Power, water, internet, phone, rates, body-corporate, or similar household bills.
- Receipts for household services, trades, cleaning, repairs, or minor purchases.
- Useful account reference documents and cancellation confirmations.

## What not to put here

- Active insurance policies — use `03_INSURANCE/Current`.
- Product manuals and warranties — use `07_WARRANTIES_AND_MANUALS`.
- Bank statements — use `08_BANKING_AND_FINANCE`.
- Tax-first evidence if tax time is the main reason you are keeping it.

## What to do with it

1. File by date and supplier.
2. Keep only what you have a reason to keep; do not turn this into a junk drawer.
3. Add recurring renewals or contract end dates to `templates/renewal-tracker.csv`.
4. Move old clutter to `99_ARCHIVE` only if you genuinely need to keep it.

## Quick rule

If the document has a renewal, expiry, cancellation, or contract date, put that date in the renewal tracker now.
