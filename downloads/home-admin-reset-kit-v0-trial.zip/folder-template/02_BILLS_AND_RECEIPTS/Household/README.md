# Household

General household receipts and admin documents that are not better filed under tax, insurance, warranties, vehicles, or home/property.
