# Medical

Medical, dental, optical, pharmacy, and health-related receipts or statements you may need later. Keep sensitive records private and avoid over-sharing copies.
