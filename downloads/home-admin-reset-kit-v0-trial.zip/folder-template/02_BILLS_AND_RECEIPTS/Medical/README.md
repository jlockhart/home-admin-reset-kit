# Medical Bills and Receipts

Use this for medical, dental, pharmacy, optical, therapy, or health-service bills and receipts that you want to keep for reimbursement, reference, or household records.

## What goes here

- Medical invoices, receipts, and payment confirmations.
- Health-insurance claim receipts or claim correspondence.
- Dental, optical, pharmacy, physio, specialist, or therapy receipts.

## What not to put here

- Full clinical records unless you intentionally choose this folder for them.
- Emergency medical instructions or critical health info that someone must find quickly — keep those in your agreed household emergency place.
- Insurance policy documents — use `03_INSURANCE/Current`.

## What to do with it

1. File by date, provider, and person if helpful.
2. Record reimbursement/claim status in your own notes if a receipt is waiting on action.
3. Add major or recurring health expenses to the document index only if you need quick retrieval.
4. Archive older receipts once claims and disputes are closed.

## Quick rule

Separate “receipt I might need for money/admin” from “medical record someone needs for care.” This folder is mainly for admin receipts.
