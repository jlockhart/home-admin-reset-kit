# Utilities

Use this for power, gas, water, internet, mobile, waste, security monitoring, and other utility account records.

## What goes here

- Utility bills and statements.
- Plan change confirmations, contract terms, cancellation confirmations, and meter/account references.
- Important service-fault or installation paperwork.

## What not to put here

- Banking transaction exports.
- Warranties/manuals for utility equipment.
- General household receipts that are not utility accounts.

## What to do with it

1. Keep the latest account details easy to find.
2. Add contract end dates, fixed-rate expiry dates, and renewal reminders to `templates/renewal-tracker.csv`.
3. Delete or archive old bills if you no longer have a reason to keep them.
4. If a utility bill is tax-relevant, copy or cross-reference it in the correct tax-year folder.

## Quick rule

The most useful utility records are current account numbers, renewal dates, and cancellation/plan-change proof.
