# Utilities

Power, water, rates, phone, internet, and similar recurring household bills. Use clear dates and supplier names so disputes and annual reviews are easy.
