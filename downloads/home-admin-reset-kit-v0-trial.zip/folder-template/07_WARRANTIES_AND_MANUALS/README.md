# Warranties and Manuals

Use this for product warranties, manuals, serial numbers, purchase receipts for durable goods, installation guides, and maintenance notes.

## What goes here

- Appliance, electronics, tool, furniture, heat pump, alarm, solar, plumbing, and similar manuals or warranty documents.
- Purchase receipts needed for warranty claims.
- Serial numbers, installation certificates, service notes, and maintenance schedules.

## What not to put here

- Insurance policies.
- Everyday small receipts you will never claim on.
- Passwords or admin login details for devices.

## What to do with it

1. File by item or room/category.
2. Add warranty expiry dates to `templates/renewal-tracker.csv`.
3. Keep the purchase receipt with the manual/warranty if needed for claims.
4. Remove documents for items you no longer own.

## Quick rule

If it could help you repair, sell, maintain, or claim warranty on an item, keep it here.
