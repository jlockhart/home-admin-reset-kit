# 07 Warranties And Manuals

Appliance manuals, warranty certificates, purchase receipts, serial numbers, and support notes. File by item or room if the folder grows.
