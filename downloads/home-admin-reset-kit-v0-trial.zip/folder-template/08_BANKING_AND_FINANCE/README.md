# Banking and Finance

Use this for banking, loans, investments, KiwiSaver/superannuation, credit cards, major account documents, and financial admin records.

## What goes here

- Bank account opening/closure documents, loan/mortgage records, statements you intentionally keep, investment summaries, KiwiSaver/super statements, and major finance correspondence.
- Interest/rate change letters and loan renewal/fixed-rate notices.
- Proof of payment or account confirmations for important transactions.

## What not to put here

- Passwords, PINs, 2FA codes, seed phrases, or full card details.
- Everyday receipts that belong in Bills and Receipts or Tax.
- Advice notes pretending to be financial advice — keep professional advice clearly labelled.

## What to do with it

1. Add loan/fixed-rate/credit-card/insurance-adjacent renewal dates to `templates/renewal-tracker.csv`.
2. Add major accounts and policy-like documents to `templates/document-index.csv`.
3. Keep sensitive files in private storage with appropriate protection.
4. Archive old statements unless you have a clear reason to keep them active.

## Quick rule

Track where the accounts are and when decisions are due; do not store secrets here.
