# 99 Archive

Cold storage for records you are keeping but do not need in active folders. Keep the structure simple and move items here deliberately, not as a dumping ground.
