# Archive

Use this for old documents you may need later but do not want in the active filing system.

## What goes here

- Superseded policies, old contracts, closed account records, sold-asset documents, completed tax-year material, and stale household records you still want to keep.
- Bundles of older paperwork that are already labelled enough to find later.

## What not to put here

- Current active documents.
- Unsorted inbox clutter.
- Documents you should confidently delete instead of keeping forever.

## What to do with it

1. Archive only after the active folder has the current version.
2. Label archive folders by year, topic, and reason for keeping.
3. Set a future review/deletion date if the records do not need to be kept indefinitely.
4. Keep sensitive archives protected just like active sensitive documents.

## Quick rule

Archive is not a second inbox. If you cannot name why you are keeping it, reconsider keeping it.
