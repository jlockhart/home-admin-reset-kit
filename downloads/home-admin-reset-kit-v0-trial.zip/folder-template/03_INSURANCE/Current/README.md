# Current Insurance

Use this for active insurance policies, schedules, certificates, claim contacts, renewal notices, and proof of cover.

## What goes here

- Home, contents, car, life, health, travel, pet, landlord, or other active policy documents.
- Current policy schedule, certificate of insurance, wording, excess details, and claims contact instructions.
- Renewal notices and premium-change letters while you are deciding what to do.

## What not to put here

- Expired policies once replaced — move those to `03_INSURANCE/Archive`.
- General bills that are not insurance.
- Legal advice or claim strategy notes unless clearly labelled and private.

## What to do with it

1. Keep only the latest active version here where possible.
2. Add policy renewal dates and insurer contacts to `templates/renewal-tracker.csv`.
3. Add major policies to `templates/document-index.csv` so they are findable in a hurry.
4. When a new policy starts, move the old policy to Archive.

## Quick rule

If someone had to make a claim tomorrow, this folder should show what is covered, who to contact, and the policy number.
