# Insurance Archive

Use this for expired or replaced insurance policies that you still want to keep for reference.

## What goes here

- Old policy schedules, certificates, wording, and renewal notices.
- Claim correspondence for closed claims.
- Cancellation confirmations or proof of prior cover.

## What not to put here

- Current active policy documents — keep those in `03_INSURANCE/Current`.
- Random bills or unrelated account records.

## What to do with it

1. Move expired policies here when the replacement is safely in Current.
2. Label closed claims clearly by date, insurer, and claim type.
3. Periodically delete/archive older records according to your own retention needs or professional advice.

## Quick rule

Current folder is for action. Archive is for evidence.
