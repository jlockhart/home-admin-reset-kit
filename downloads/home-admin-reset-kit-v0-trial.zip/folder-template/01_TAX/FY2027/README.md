# FY2027

Tax-year folder for records belonging to FY2027. Use this for tax-year-first evidence such as receipts, statements, invoices, and return-supporting documents.
