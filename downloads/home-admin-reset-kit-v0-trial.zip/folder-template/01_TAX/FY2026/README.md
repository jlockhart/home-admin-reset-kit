# FY2026 Tax Records

Use this for records that belong to the FY2026 tax year. In New Zealand, that generally means 1 April 2025 to 31 March 2026.

## What goes here

- Income records, invoices, statements, or summaries relevant to this tax year.
- Deductible-expense receipts or evidence you may need later.
- Donation receipts, interest statements, or investment/tax summaries.
- Copies of filed returns or accountant correspondence for this year.

## What not to put here

- Current-year records that belong in FY2027 or later.
- General household manuals or warranties unless they are tax evidence.
- Advice notes pretending to answer tax/legal questions — keep professional advice separately and clearly labelled.

## What to do with it

1. File by date and clear name: `YYYY-MM-DD - Supplier - What it is.pdf`.
2. Add important items to `templates/document-index.csv` if you might need to find them quickly.
3. Put missing evidence into `templates/missing-documents-list.csv`.
4. After filing a return, save the final return/summary and mark the year as complete.

## Quick rule

If you are not sure whether something is tax-relevant, file it here temporarily and ask your accountant later. This kit does not decide tax treatment.
