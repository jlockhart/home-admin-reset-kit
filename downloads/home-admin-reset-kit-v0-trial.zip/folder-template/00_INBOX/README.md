# 00 Inbox

Use this as the temporary landing area for new PDFs, scans, receipts, phone photos, downloads, and email attachments before they are filed.

## What goes here

- Anything you are not ready to file yet.
- Fresh scans or photos from your phone.
- Downloaded bills, statements, receipts, policies, certificates, and forms.
- Email attachments you saved but have not renamed.

## What not to put here

- Permanent archives.
- Old documents you have already filed somewhere sensible.
- Passwords, recovery codes, or secrets.

## What to do with it

1. Empty this folder once a week.
2. Rename obvious documents using `templates/filename-rules.md`.
3. Move tax-year evidence into `01_TAX`.
4. Move category documents into the matching folder such as Insurance, Home, Vehicles, Warranties, Identity, or Banking.
5. Add only important long-lived records to `templates/document-index.csv`.

## Quick rule

If it has sat here for more than 7 days, spend 10 minutes filing the obvious items and move the confusing ones to the missing-documents list with a next action.
