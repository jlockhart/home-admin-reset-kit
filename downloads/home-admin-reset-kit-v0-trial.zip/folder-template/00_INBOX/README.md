# 00 Inbox

Temporary landing area for new PDFs, scans, receipts, photos, and email attachments before filing. Empty this weekly; do not let it become the permanent filing cabinet.
