# Capture Inbox Guide

The goal is not to organise everything perfectly on day one. The goal is to make sure important documents stop disappearing.

## Create one temporary inbox

Create a folder called `00_INBOX` in your filing cabinet. For the first week, everything goes there.

Good inbox sources:

- downloaded PDFs
- email attachments
- scanned paper
- phone photos of receipts
- warranty PDFs
- insurance renewals
- contracts or signed forms

## Email capture

Create a simple label or folder in your email called `Filing Cabinet Inbox`.

When you see an important document:

1. Save the attachment to `00_INBOX`, or
2. Label the email `Filing Cabinet Inbox` so you can process it later.

Do not rely on memory. If it matters, capture it.

## Phone/photo capture

For paper documents:

1. Take a clear photo or scan.
2. Save/export it as PDF if possible.
3. Put it in `00_INBOX`.
4. Rename it later, not while you are standing at the kitchen bench.

## Weekly processing rhythm

Once per week, spend 10 minutes:

- move obvious files out of `00_INBOX`
- rename only the files you expect to search for later
- add important items to `document-index.csv`
- leave ambiguous items in the inbox rather than inventing a category

## Rule of thumb

If you would be annoyed to lose it, capture it. If you would need it for tax, insurance, warranty, legal proof, or a future sale, capture it.
