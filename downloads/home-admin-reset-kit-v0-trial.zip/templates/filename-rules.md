# Filename Rules

Use boring names that sort well and make sense in search.

## Default pattern

`YYYY-MM-DD_counterparty_short-description.ext`

Examples:

- `2026-05-01_vector_power-bill.pdf`
- `2026-04-12_aa_car-insurance-renewal.pdf`
- `2025-11-03_noel-leeming_dishwasher-receipt.pdf`

## If no exact date

Use the best known month or year:

- `2026-05_vector_power-bill.pdf`
- `2026_passport-renewal.pdf`

## Keep names simple

- lowercase is fine
- spaces are okay, but hyphens are usually cleaner
- avoid `final_final_v3.pdf`
- include the counterparty when useful
- include the asset when useful, e.g. `mazda`, `dishwasher`, `house`
