# Privacy and Backup Guide

This kit is meant to keep your documents in your own storage. It does not need you to upload documents to the kit builder or to any AI service.

## 1. Pick one private home for the filing cabinet

Choose a location you already trust and understand, such as:

- a folder on your computer
- iCloud Drive, Google Drive, Dropbox, OneDrive, or similar
- a NAS or external drive
- another private storage system you already use

Use one main location. Avoid scattering the same filing cabinet across several apps unless you have a clear backup plan.

## 2. Make the inbox easy, not public

Create `00_INBOX` inside your chosen filing cabinet. Save new PDFs, downloads, scans, and photos there first.

Before putting anything into the inbox, check that the folder is not publicly shared. If your storage app has sharing links, make sure the filing cabinet folder does not have an open link.

## 3. Use simple access rules

- Keep private documents out of shared family folders unless everyone with access should see them.
- Do not put IDs, account numbers, policy documents, tax records, legal papers, or financial records into public chat tools.
- If you use an AI assistant, describe the filing problem in general terms instead of pasting sensitive document contents.
- If you need professional help, use a qualified professional and their secure intake process.

## 4. Back up the filing cabinet

Use the 3-2-1 idea in a lightweight way:

- 3 copies of important records where practical
- 2 different places, such as cloud storage plus a local backup
- 1 copy that still works if your laptop is lost or damaged

A practical setup could be:

1. main working folder in your cloud drive
2. automatic computer backup such as Time Machine, File History, or backup software
3. occasional encrypted external-drive backup for important records

## 5. Protect the highest-risk records

Some records deserve extra care:

- passports, licences, birth/marriage/citizenship documents
- wills, trusts, powers of attorney, property records
- bank, loan, investment, insurance, and tax records
- medical and identity documents
- passwords, recovery codes, and account backup codes

For these, consider using your password manager's secure notes, encrypted storage, or another system you already trust. Do not keep password recovery codes in the same unprotected folder as the documents they unlock.

## 6. Review sharing and backup once a year

Add this to your annual checklist:

- confirm the filing cabinet folder is not publicly shared
- confirm old collaborators no longer have access
- confirm backups are still running
- confirm you can restore or open at least one backed-up file
- remove duplicate copies from random downloads, desktop, and phone photo folders when safe

## Boundary note

This is general organisation guidance, not legal, tax, financial, accounting, compliance, cybersecurity, or privacy advice. Use professional advice and secure systems where your situation requires it.
