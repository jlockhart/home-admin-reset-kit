# 7-Day Home Admin Reset Plan

Use this when a full one-hour reset feels too much. The goal is progress without turning home paperwork into a giant project.

## Day 1 — Create the inbox

- Create one digital folder called `00_INBOX`.
- Put every unsorted PDF, scan, email attachment, receipt photo, and download there first.
- Do not sort yet. The win is one capture point.

## Day 2 — Make the main folders

Copy the `folder-template/` folder into your real storage location.

If you are making folders manually, start with:

- Tax
- Bills and receipts
- Insurance
- Home and property
- Vehicles
- Identity and legal
- Warranties and manuals
- Banking and finance
- Archive

## Day 3 — File the obvious current documents

Move only the easy/high-value files first:

- current insurance policies
- recent bills and receipts you may need again
- important identity/legal files
- major warranty/manual files
- vehicle or property documents

Leave ambiguous files in `00_INBOX` rather than getting stuck.

## Day 4 — Rename only what matters

Use boring names that sort naturally:

```text
YYYY-MM-DD - provider - document type - short note.pdf
```

Examples:

```text
2026-04-03 - insurer - home policy renewal.pdf
2026-05-01 - power company - electricity bill.pdf
2026-05-18 - appliance store - washing machine receipt.pdf
```

Rename important files. Do not waste time beautifying trivial receipts.

## Day 5 — Start the tiny index

Use `templates/document-index.csv` for documents you may need to find later:

- insurance policies
- legal/identity records
- tax evidence
- warranties and major purchases
- contracts
- anything with a renewal or expiry date

You do not need to index every small receipt.

## Day 6 — Make the missing-documents list

Use `templates/missing-documents-list.csv` to record what you still need to find, scan, request, or download.

This is better than pretending the filing cabinet is complete.

## Day 7 — Set a 10-minute weekly habit

Once a week:

- empty the inbox
- file obvious documents
- update the index
- add missing items to the chase-list
- add renewal/expiry dates to the renewal tracker

Ten minutes is enough if the system stays simple.

## Boundary

This is an organisation plan, not tax, legal, financial, accounting, or compliance advice. Keep records required for your own situation and use qualified advice where needed.
