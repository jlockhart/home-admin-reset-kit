# Tax-Year Filing Guide

This kit uses an April–March tax year convention by default, which matches New Zealand personal and business tax years.

Adjust the dates if your country or entity uses a different tax year.

## Folder convention

Use `FY2027` to mean the tax year ending in 2027.

For New Zealand:

- `FY2026` = 1 April 2025 to 31 March 2026
- `FY2027` = 1 April 2026 to 31 March 2027
- `FY2028` = 1 April 2027 to 31 March 2028

## What belongs in tax-year folders

Use tax-year-first filing when the main question is:

> What documents belong with this tax/accounting year?

Examples:

- income summaries
- deductible receipts
- donation receipts
- invoices
- business or sole-trader expenses
- home-office evidence
- accountant correspondence
- tax return copies and assessments

## What does not belong only in tax-year folders

Some documents are better filed by category or asset because you need the current/latest version quickly:

- passport
- driver licence
- will or legal documents
- current insurance policy
- house title or settlement documents
- vehicle ownership/service history
- appliance manuals and warranties

If a document is both tax-relevant and asset-relevant, choose one home folder and reference it in the index rather than keeping duplicate copies everywhere.

## Filename examples

- `2026-04-12_accountant_tax-query.pdf`
- `2026-06-01_example-client_invoice-1042.pdf`
- `2027-03-31_bank_interest-summary.pdf`

## Reminder

This is an organisation guide, not tax or accounting advice. Keep the records required by your own jurisdiction and situation.
