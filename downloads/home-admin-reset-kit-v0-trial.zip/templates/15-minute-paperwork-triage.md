# 15-Minute Paperwork Triage

Use this when the paperwork pile is annoying but you do not have time for a full reset.

The goal is not to finish the whole filing cabinet. The goal is to stop the next important thing from being lost.

## Before you start

Set a 15-minute timer and open only three places:

1. your physical pile, email attachments, downloads folder, or phone photos
2. the kit's `00_INBOX` folder
3. `templates/missing-documents-list.csv` and `templates/renewal-tracker.csv`

Do not open every old folder. Do not redesign the system.

## Minute 0-3: separate by urgency

Make three piles or temporary folders:

- **Act this week** — due dates, renewal notices, bills, forms, expiring IDs, appointment paperwork
- **File later** — receipts, statements, manuals, warranty PDFs, policy schedules, reference records
- **Probably clutter** — duplicates, old marketing PDFs, non-essential screenshots, things you can re-download easily

If a document contains private ID, tax, banking, legal, medical, or insurance details, keep it in your private storage and do not paste it into public tools.

## Minute 3-8: capture the important items

Move or save the important items into `00_INBOX`.

Use quick names if needed:

```text
YYYY-MM-DD_provider_document-type_CHECK.pdf
```

Examples:

```text
2026-06-09_example-insurer_policy-renewal_CHECK.pdf
2026-06-09_city-council_rates-notice_CHECK.pdf
2026-06-09_appliance-store_washing-machine-receipt_CHECK.pdf
```

`CHECK` is a useful flag. It means future-you knows the file exists but still needs a decision.

## Minute 8-12: add only the obvious tracker rows

Add renewal or expiry items to `renewal-tracker.csv`.

Add missing records to `missing-documents-list.csv`.

Keep the note boring and actionable:

- "find latest policy schedule"
- "request receipt from store"
- "check whether warranty is still current"
- "download latest statement from provider portal"

Do not add every small receipt. Track the records you would actually worry about losing.

## Minute 12-15: choose one next action

Pick one action that reduces risk:

- pay or schedule a due bill
- request a missing document
- download a policy schedule
- file an expiring ID reminder
- scan one important paper document
- move private records out of a shared folder

Write the next action in your normal task list or calendar. Then stop.

## Stop rule

When the timer ends, stop. A triage pass is a safety pass, not a full tidy-up.

Use the 60-minute quick start or 7-day reset plan later when you have more energy.

## Boundary note

This is an organisation checklist, not tax, legal, financial, accounting, or compliance advice. Use qualified professional advice where needed.
