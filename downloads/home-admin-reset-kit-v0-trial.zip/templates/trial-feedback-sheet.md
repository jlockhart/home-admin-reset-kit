# Trial feedback sheet

Thanks for trying the Home Admin Reset Kit trial.

Please do **not** send private documents, account numbers, tax files, insurance papers, IDs, passwords, or screenshots that contain personal details.

## 5-minute feedback

1. What were you trying to get under control?  
   _Example: tax papers, insurance, house documents, warranties, family admin, everything._

2. Which part of the trial kit was most useful?  
   _Example: folder template, setup path picker, 15-minute triage, 7-day reset plan, privacy/backup guide._

3. Where did you get stuck or feel unsure?

4. What is missing that would make this easier to actually use?

5. If there was a paid full version, what would make it worth paying for?  
   _Examples: more templates, printable checklists, country-specific examples, household handover pack, renewal reminders, guided setup._

## Optional quick scores

- Clarity: 1 2 3 4 5
- Usefulness: 1 2 3 4 5
- Trust/safety: 1 2 3 4 5
- Would recommend to a friend: yes / maybe / no

## If you are copying this into a form

Suggested field names:

- `problem_to_control`
- `most_useful_part`
- `stuck_or_unsure`
- `missing_or_harder_than_expected`
- `paid_version_trigger`
- `clarity_score`
- `usefulness_score`
- `trust_safety_score`
- `recommendation`

Do not add a file-upload field. Feedback should be text-only.

## Privacy reminder

Feedback about the kit is useful. Private documents are not needed and should not be shared.
