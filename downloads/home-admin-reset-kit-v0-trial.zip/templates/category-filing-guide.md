# Category-First Filing Guide

Use category-first filing when the main question is:

> Where is the current or important document for this thing?

This is different from tax-year filing. You are organising around the real-world object or responsibility, not a return period.

## Good category-first records

### Identity and legal

- passport
- driver licence
- birth/marriage/citizenship documents
- wills and enduring powers of attorney
- trust/company/legal documents

### Insurance

- current policy schedules
- renewal notices
- claim documents
- old policies in `Archive`

### Home and property

- purchase/settlement documents
- rates notices
- renovation records
- appliance inventory
- contractor documents

### Vehicles

- ownership records
- service history
- WOF/registration documents
- insurance and claims

### Warranties and manuals

- major purchase receipts
- serial numbers
- manuals
- warranty terms

## Current vs archive

For policies and recurring documents, keep the latest version easy to find and move older versions into `Archive`.

Example:

- `03_INSURANCE/Current/2026-05-01_example-insurer_home-policy.pdf`
- `03_INSURANCE/Archive/2025-05-01_example-insurer_home-policy.pdf`

## Cross-reference in the index

If a document might be searched for in more than one way, do not duplicate it. Add notes or tags in `document-index.csv`.

Example:

- category: `vehicle`
- notes: `Mazda; insurance; renewal due 2027-04-12`
