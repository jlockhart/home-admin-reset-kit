# First-hour home admin setup

Use this when you want one useful hour, not a perfect filing system.

## Before you start

- Pick one storage location you already trust: Finder, iCloud Drive, Google Drive, Dropbox, OneDrive, a NAS, or similar.
- Do not upload private documents anywhere new just to use this kit.
- Keep sensitive originals where they already belong.

## Minute 0–10: create the capture point

1. Copy the `folder-template/` folder into your storage location.
2. Rename the copied folder to something obvious, such as `Home Admin Filing Cabinet`.
3. Open `00_INBOX`.
4. Add one text note called `START-HERE.txt` if that helps you remember what the folder is for.

The first win is having one place where unsorted documents can land.

## Minute 10–25: collect only the easy items

Move or copy a small batch into `00_INBOX`:

- recent PDF bills
- recent insurance documents
- warranty PDFs or manuals you already have downloaded
- scanned IDs or legal documents already stored digitally
- receipts you know you will want later

Do not search every mailbox, drawer, phone, or old backup today. That turns a one-hour setup into an archaeology project.

## Minute 25–40: file the obvious current documents

Move only the obvious files from `00_INBOX` into the main folders:

- tax-year records into `01_TAX`
- household bills and receipts into `02_BILLS_AND_RECEIPTS`
- current policies into `03_INSURANCE/Current`
- property records into `04_HOME_AND_PROPERTY`
- vehicle records into `05_VEHICLES`
- identity/legal copies into `06_IDENTITY_AND_LEGAL`
- warranties and manuals into `07_WARRANTIES_AND_MANUALS`
- banking/finance records into `08_BANKING_AND_FINANCE`

If a file is ambiguous, leave it in `00_INBOX`. The system should keep momentum, not create decision fatigue.

## Minute 40–50: rename only high-value files

Use the boring filename rule for anything you are likely to search for later:

`YYYY-MM-DD - provider - document type - short note.pdf`

Examples:

- `2026-03-31 - insurer - home insurance renewal.pdf`
- `2026-04-08 - appliance store - dishwasher receipt.pdf`
- `2026-05-12 - council - rates notice.pdf`

Do not rename every small receipt. Rename the files that would be annoying to lose.

## Minute 50–60: make the chase-list

Open `templates/missing-documents-list.csv` and add only the missing items you already know about.

Useful prompts:

- What policy, ID, warranty, or account document would be painful to find in a hurry?
- What renewal or expiry date do I often forget?
- What document is still only in paper form?
- What document is still buried in email?

Stop after one hour. A partial, trusted filing cabinet beats a perfect system that never gets started.

## Boundary

This is an organisation workflow only. It is not tax, legal, financial, accounting, insurance, or compliance advice. Keep records required for your own situation and use qualified professional advice where needed.
