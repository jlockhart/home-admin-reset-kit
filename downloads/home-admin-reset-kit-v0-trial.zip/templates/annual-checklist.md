# Annual Home Admin Checklist

Run once per year, ideally near tax time or insurance renewal season.

## Inbox

- [ ] Empty `00_INBOX`
- [ ] Rename unclear files
- [ ] Move each file into tax-year or category folders
- [ ] Update `document-index.csv` for important records

## Tax/accounting

- [ ] Collect deductible receipts
- [ ] Collect income summaries
- [ ] Collect donation receipts
- [ ] Collect home-office or work-related records if relevant
- [ ] Check FY folders use April–March tax years

## Insurance

- [ ] Confirm current house/contents/car/pet/life policies are filed
- [ ] Record renewal dates
- [ ] Archive old policies

## Identity/legal

- [ ] Check passport/driver licence expiry dates
- [ ] Confirm wills/trust/legal docs are findable
- [ ] Do not store passwords in this kit

## Assets/warranties/manuals

- [ ] File major purchase receipts
- [ ] File appliance manuals/warranties
- [ ] File vehicle service history
- [ ] File house/property documents

## Backup

- [ ] Confirm the filing cabinet is backed up
- [ ] Confirm private cloud mirror/access works if used
