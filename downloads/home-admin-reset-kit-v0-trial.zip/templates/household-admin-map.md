# Household Admin Map

Use this one-page map to make your home admin system easier to understand later. It is for organisation only. Do not put passwords, full account numbers, private IDs, or secret recovery codes in this file.

## What this map is for

A filing system works better when you know where the important areas live and what to check first. This map gives you a plain overview of your household admin setup without exposing the private documents themselves.

## Safe version first

Keep this document boring and low-risk. It can mention that you have an insurance folder, a renewal tracker, or a tax-year archive. It should not contain sensitive details that would create risk if someone opened it.

Good examples:

- Main document storage: private cloud drive / home computer / NAS / external drive
- Inbox folder: `00_INBOX`
- Renewal tracker: `templates/renewal-tracker.csv`
- Important annual review month: March
- Backup check month: January and July

Avoid:

- passwords or passphrases
- bank account numbers
- tax IDs, passport numbers, licence numbers, policy numbers, claim numbers, customer numbers
- photos or scans of identity records
- private links that bypass normal account security

## One-page map

Copy and fill this in.

```text
HOME ADMIN MAP
Last updated:

Main storage location:
Backup location:
Who has access:

Inbox folder:
Document index:
Renewal tracker:
Missing-documents list:

Main categories:
- Tax-year records:
- Bills and receipts:
- Insurance:
- Home/property:
- Vehicles:
- Identity/legal:
- Warranties/manuals:
- Banking/finance:
- Archive:

Monthly routine day:
Annual review month:
Backup/privacy check months:

Notes for future me:
```

## Access and sharing check

Once a year, review who can see the storage location and shared folders. Remove old shared links, old household members, ex-flatmates, contractors, or devices you no longer use.

## Emergency-use boundary

If you want a trusted person to know where important records are, tell them the storage location and category structure separately from passwords and identity documents. Use your normal password manager, legal arrangements, or professional advice for anything sensitive or formal.

## AI-use boundary

It is fine to ask an AI assistant to help design folder names, checklists, or routines. Do not paste private documents, IDs, legal records, policy documents, tax records, medical records, account statements, or passwords into a random AI chat.

## Review prompt

Every six months, ask:

1. Could I find the latest insurance, ID, vehicle, warranty, property, and tax-year records quickly?
2. Is the inbox small enough that I still trust it?
3. Do the trackers still match reality?
4. Are backups working?
5. Are shared folders and links still appropriate?

If the answer is no, schedule one short reset session rather than trying to fix everything at once.
