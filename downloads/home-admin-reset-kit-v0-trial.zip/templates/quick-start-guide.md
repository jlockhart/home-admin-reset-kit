# Home Admin Reset Kit — Quick Start

## The 60-minute reset

### 1. Create one inbox

Start with `00_INBOX`. For one week, put every new PDF, receipt, scan, and important attachment there.

Do not design the perfect system first. Capture first.

### 2. Copy the folder template

Copy `folder-template/` to wherever your real filing cabinet will live: laptop, cloud drive, NAS, or private repo.

### 3. Use two filing rules

**Tax-year-first:** file by tax year when the question is “what belongs in this return/year?”

Examples:

- tax records
- deductible receipts
- accounting evidence
- bills/receipts linked to business or sole-trader expenses

**Category-first:** file by category/asset when the question is “where is the current/important document?”

Examples:

- passport
- will
- insurance policy
- vehicle history
- appliance manual
- house legal pack

### 4. Rename only the important files

Use:

`YYYY-MM-DD_counterparty_short-description.ext`

Do not spend hours beautifying everything. Rename the documents you actually need to find again.

### 5. Index only what matters

Use `document-index.csv` for important records, renewals, warranties, tax docs, and anything you might search for later.

You do not need to index every trivial receipt.

### 6. Track missing documents and renewals

Use:

- `missing-documents-list.csv` for documents you know you still need to find or request
- `renewal-tracker.csv` for passports, licences, insurance policies, warranties, subscriptions, and other expiry/renewal dates

Do not make this perfect. Capture enough that future-you knows what to chase.

### 7. Weekly maintenance

Once a week:

- empty the inbox
- file obvious documents
- add key records to the index
- add missing documents to the chase-list
- add renewal or expiry dates to the renewal tracker

Ten minutes is enough.

## Read next

- `setup-path-picker.md` if you are not sure whether to start with triage, one-hour setup, the 7-day plan, maintenance, the household map, or privacy checks
- `15-minute-paperwork-triage.md` for a quick safety pass when you do not have time for the full setup
- `filename-rules.md` for naming examples
- `tax-year-guide.md` for April–March / FY filing
- `category-filing-guide.md` for identity, legal, insurance, home, vehicle, warranty, and manual records
- `capture-inbox-guide.md` for email/download/phone capture
- `privacy-and-backup-guide.md` for private storage, sharing, and backup checks
