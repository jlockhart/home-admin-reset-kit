# Monthly Home Admin Maintenance Routine

Use this once a month to keep the filing cabinet useful without turning it into a second job. Aim for 20–30 minutes. Stop when the timer ends; the system should reduce stress, not create more admin.

## Before you start

- Open your `00_INBOX` folder.
- Open `document-index.csv` only if you are tracking key records there.
- Open `renewal-tracker.csv` if you expect renewals, expiries, warranties, subscriptions, IDs, or insurance dates.
- Do not upload private documents to an AI tool or public service while doing this routine.

## 1. Empty the obvious inbox items

File documents that are easy to classify:

- insurance schedules, renewals, claims, and invoices
- utility, rates, rent, mortgage, body corporate, or property-service bills
- receipts for appliances, repairs, warranties, vehicle work, or other high-value items
- tax-year documents and income/expense records
- identity, legal, banking, vehicle, and property documents

If a document is unclear, leave it in `00_INBOX` with a short filename note such as `CHECK - unknown insurance PDF - 2026-06.pdf`.

## 2. Rename only what matters

Do not spend the whole session perfecting filenames. Rename documents where the current name would make them hard to find later.

Suggested pattern:

```text
YYYY-MM-DD - Provider - Document Type - Short Detail.pdf
```

Examples:

```text
2026-06-01 - PowerCo - Electricity Bill - Home.pdf
2026-06-04 - Appliance Store - Receipt - Washing Machine.pdf
2026-06-08 - Insurer - Car Policy Schedule - Current.pdf
```

## 3. Update trackers lightly

Add or update rows only for records you may need to find, renew, prove, claim, sell, repair, insure, or hand over.

Use `renewal-tracker.csv` for:

- insurance renewals
- passport, licence, visa, certification, or membership expiries
- warranties and service dates
- subscriptions or recurring admin dates worth noticing

Use `missing-documents-list.csv` for:

- documents you expected to have but cannot find
- documents someone needs to send you
- documents you need to request from a provider

## 4. Archive old current documents

When a newer version arrives, keep the active copy easy to find and move older versions into an archive folder.

Examples:

- Move last year’s insurance schedule from `03_INSURANCE/Current/` to `03_INSURANCE/Archive/`.
- Keep the latest property rates notice visible; archive older duplicates by year.
- Leave tax-year material in the matching tax-year folder.

## 5. Run a quick privacy check

Check whether anything sensitive landed in the wrong place:

- IDs, legal papers, banking records, and tax records should not be in a shared family folder unless that is deliberate.
- Screenshots and phone photos of private documents should be moved or deleted after filing.
- Shared links should be reviewed if the file contains account numbers, identity details, signatures, medical details, or legal information.

## 6. Make one next action visible

If the routine surfaces a problem, write down exactly one next action.

Examples:

- `Request updated home insurance schedule from insurer.`
- `Find receipt for washing machine warranty.`
- `Ask accountant what records are needed for this expense category.`
- `Scan passport and store in private identity folder.`

Put that action in your normal task list. Do not leave it buried in the filing system.

## Stop rule

When the timer ends, stop. A calm filing cabinet is maintained in small passes. If the inbox is still large, schedule another 20-minute session rather than trying to fix years of admin in one sitting.

## Boundary note

This routine is an organisation aid only. It is not tax, legal, financial, accounting, or compliance advice. Keep private records in your own storage and use qualified professional advice where needed.
