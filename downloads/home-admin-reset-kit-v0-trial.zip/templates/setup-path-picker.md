# Setup Path Picker

Use this page when you are not sure where to start. Pick one path. Do not try to do all of them today.

## If you have 15 minutes

Use `15-minute-paperwork-triage.md`.

Best when:

- there may be an overdue bill, renewal, or form hiding in the pile
- you feel too overwhelmed for a full reset
- you want one quick safety pass before doing anything else

Your win today: urgent items are visible and the pile is less dangerous.

## If you have one hour

Use `first-hour-setup.md` or `quick-start-guide.md`.

Best when:

- you can sit down with your laptop and make the first version of the cabinet
- you want a useful folder structure today
- you have a small pile of downloads, emails, or scans ready to sort

Your win today: one working inbox, one copied folder template, and the first obvious documents filed.

## If you are overwhelmed

Use `7-day-reset-plan.md`.

Best when:

- the backlog is large
- you keep avoiding the job
- you want small daily steps rather than a big clean-up session

Your win today: the job becomes seven small decisions instead of one giant task.

## If the system already exists but is drifting

Use `monthly-maintenance-routine.md`.

Best when:

- the inbox is filling up again
- renewals and missing documents have not been checked recently
- you need to bring the cabinet back under control

Your win today: the inbox, trackers, and privacy/backups are current enough again.

## If someone else may need to find things

Use `household-admin-map.md`.

Best when:

- a partner, executor, family member, or future-you may need to find the cabinet
- the folder structure exists but the “where is everything?” answer lives only in your head
- you want a safe map without storing passwords, account numbers, recovery codes, or private links

Your win today: the system is findable without creating a dangerous master secrets file.

## If privacy is the worry

Use `privacy-and-backup-guide.md`.

Best when:

- private IDs, legal documents, tax files, or financial records are mixed through shared folders
- you are not sure what is backed up
- you use AI tools and want a simple boundary for what not to paste or upload

Your win today: sensitive records are separated, sharing is checked, and backup gaps are visible.

## Simple rule

If in doubt, start with the 15-minute triage. A safe small pass beats another week of avoidance.
