# What should I file? Home paperwork FAQ

A calm filing cabinet works best when it answers simple real-life questions, not when it tries to keep everything forever.

## Bills and receipts

Keep bills and receipts when they prove a payment, support a warranty, help with a tax return, or explain a recurring cost. You do not need to keep every supermarket docket.

Good examples:

- insurance invoices and policy schedules
- utility bills that explain account numbers or unusual charges
- rates, water, body corporate, or property-service bills
- receipts for appliances, repairs, warranties, and higher-value household items

## Insurance

Keep the current policy schedule, renewal notice, premium invoice, claim correspondence, and anything that proves what is covered. Archive old policies by year so the current one stays easy to find.

## Tax and income records

Keep documents that your accountant, tax authority, or future self may need to explain income, deductible expenses, donations, interest, dividends, rental-property costs, or business costs. Use your local tax year. If unsure, keep the record and ask a qualified professional later.

## Identity and legal

Keep scans or references for passports, birth certificates, wills, trust documents, powers of attorney, enduring powers, marriage certificates, and other high-value records. Store these more carefully than ordinary bills. Do not paste these into random AI tools.

## Warranties and manuals

Keep receipts, serial numbers, installation records, warranty PDFs, manuals for expensive items, and service history. Put the model number in the filename where useful.

## What not to keep

Do not keep everything by default. Avoid clutter from expired marketing PDFs, duplicate downloads, unread newsletters, routine shopping emails, and app notifications that do not prove anything.

## The simple rule

If the document could help you prove, renew, claim, sell, repair, tax, insure, or hand over something important, file it. If it is just noise, delete or ignore it.

This is an organisation guide, not tax, legal, financial, accounting, or compliance advice.
