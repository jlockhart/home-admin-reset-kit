# Home Admin Reset Kit v0

A practical digital filing cabinet starter kit for household and sole-trader admin.

## Contents

- `folder-template/` — ready-to-copy folder structure
- `templates/quick-start-guide.md` — 60-minute setup guide
- `templates/filename-rules.md` — naming conventions
- `templates/tax-year-guide.md` — tax-year-first filing guide, using April–March NZ convention by default
- `templates/category-filing-guide.md` — category-first guide for identity/legal/assets/insurance/warranties/manuals
- `templates/capture-inbox-guide.md` — how to capture email, downloads, scans, and phone photos
- `templates/document-index.csv` — simple metadata/index spreadsheet
- `templates/missing-documents-list.csv` — chase-list for important documents you still need
- `templates/renewal-tracker.csv` — renewal/expiry tracker for policies, IDs, warranties, and similar records
- `templates/annual-checklist.md` — yearly review checklist

## Suggested use

1. Copy `folder-template/` to your real storage location.
2. Put every new document into `00_INBOX` for one week.
3. Use the quick-start guide to file the obvious items.
4. Track important records in `document-index.csv`.
5. Track missing documents and renewal dates in the two CSV trackers.
6. Run the annual checklist once per year.

## Boundaries

This kit is a self-serve organisation template. It does not provide tax, legal, financial, accounting, or compliance advice, and it does not tell you what records your situation requires.

Keep your real documents in your own private storage. The example rows and folder notes in this kit are dummy examples only; replace them with your own categories and professional advice where needed.

## Status

Private draft. Do not publish until public positioning and channel are approved.
